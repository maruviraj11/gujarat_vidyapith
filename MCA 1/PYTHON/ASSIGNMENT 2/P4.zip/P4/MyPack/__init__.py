from .parser import evaluate
